from game import *
run(state_intro)